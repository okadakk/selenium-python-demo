from time import sleep
from test_tool import TestTool

t = TestTool()
t.set_driver_url('https://okadak-pc.kaigo-dev.homes.co.jp/inquire/facility/f=50044/')

# symfony debug toolbar hide
t.hide_symfony_toolbar()

# name input require test
t.require_test("//input[@id='inquire_facility_name']", 'せれにうむてすと')

# kana input require test
t.require_test("//input[@id='inquire_facility_ruby']", 'セレニウムテスト')

# postal code and address input test
t.address_input_test("//input[@id='inquire_facility_zipcode_str']", '213-0001', "//input[@id='inquire_facility_address_area']", '1-2')

# address input require test
t.require_test("//input[@id='inquire_facility_address_area']", '住所hogehoge')

# tel code require test
t.require_test("//input[@id='inquire_facility_tel']", '09090909090')

# submit test
t.submit_test("//div[@class='btnField']//input[@type='submit']")

sleep(3)
# t.close_driver()
